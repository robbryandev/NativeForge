import { Linking } from 'react-native'

export const openURL = (url: string) => Linking.openURL(url)
