export { default as NextLink } from 'next/link'
