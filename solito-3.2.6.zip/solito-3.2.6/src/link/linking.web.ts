// noop, not supported on web
export const openURL = (url: string) => {}
