import type Link from 'next/link'

export const NextLink = (() => {
  return <></>
}) as any as typeof Link
