export const useNavigation = () => undefined
