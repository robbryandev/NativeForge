export const NextRouter = undefined
