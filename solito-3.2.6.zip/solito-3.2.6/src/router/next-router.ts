import Router from 'next/router'

export const NextRouter: typeof Router | undefined = Router
