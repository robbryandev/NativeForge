import type { useRouter } from 'next/router'

export const useNextRouter = (): ReturnType<typeof useRouter> | undefined =>
  undefined
