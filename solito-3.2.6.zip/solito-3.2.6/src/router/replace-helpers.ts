import {
  StackActions,
  getStateFromPath,
  getActionFromState,
} from '@react-navigation/native'
// THIS IS DANGEROUS
// IT ONLY WORKS ON NATIVE BECAUSE NATIVE USES THE SRC FOLDER CURRENTLY.
// THIS IS SUPER UNSAFE
// WE SHOULD BE USING THE EXPOSED VARIABLE
// see: https://github.com/react-navigation/react-navigation/discussions/10517
// PR: https://github.com/react-navigation/react-navigation/pull/10604
import LinkingContext from '@react-navigation/native/src/LinkingContext'

export { LinkingContext, StackActions, getStateFromPath, getActionFromState }
