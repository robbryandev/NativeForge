export { default } from '../expo/image.web'
