export { default } from 'next/router'
