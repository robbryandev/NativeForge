import { NextRouter } from 'next/router'

export const useRouter = () => undefined as NextRouter | undefined
