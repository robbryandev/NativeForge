import { useRouter as _useRouter } from 'next/router';

export const useRouter = () => _useRouter();