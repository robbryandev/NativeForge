export const useRoute = () => undefined
