import type Router from 'next/router'

export default undefined as any as typeof Router
