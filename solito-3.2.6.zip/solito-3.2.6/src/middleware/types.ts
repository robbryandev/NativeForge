import type { useLinkTo } from '@react-navigation/native'

export type MiddlewareContextType = {
  useLinkTo?: typeof useLinkTo
}
