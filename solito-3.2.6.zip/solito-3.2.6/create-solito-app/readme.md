# `create-solito-app`

```sh
npx create-solito-app@latest
```

A script that creates a [solito monorepo](https://github.com/nandorojo/solito/tree/master/example-monorepos/blank) for you in seconds.

## Contributing

- Clone the root repo.
- `cd create-solito-app`
- `yarn`
- `yarn test` to build your local app into a gitignored `create-test-app` folder

## Credits

Thanks to `create-next-app`, I was able to write `create-solito-app` in about an hour.
