/// <reference types="app/rnw-overrides" />
/// <reference types="nativewind/types" />
