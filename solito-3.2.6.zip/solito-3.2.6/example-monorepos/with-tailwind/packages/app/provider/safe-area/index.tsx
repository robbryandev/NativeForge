import { SafeAreaProvider } from 'react-native-safe-area-context'

export const SafeArea = SafeAreaProvider
