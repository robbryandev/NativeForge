import { View as ReactNativeView } from 'react-native'
import { styled } from 'nativewind'

export const View = styled(ReactNativeView)
