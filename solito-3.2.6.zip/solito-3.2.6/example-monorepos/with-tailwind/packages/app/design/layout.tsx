import { View } from 'react-native'
import { styled } from 'nativewind'

export const Row = styled(View, "flex-row")
