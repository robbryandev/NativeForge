export { SafeAreaProvider as SafeArea } from 'react-native-safe-area-context'
