import { HomeScreen } from 'app/features/home/screen'

export default HomeScreen
