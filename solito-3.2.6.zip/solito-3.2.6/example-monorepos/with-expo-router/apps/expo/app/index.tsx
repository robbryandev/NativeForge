import { HomeScreen } from 'app/features/home/screen'

export default function Home() {
  return <HomeScreen />
}
