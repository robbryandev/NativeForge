// registerRootComponent happens in "expo-router/entry"
import 'expo-router/entry'
